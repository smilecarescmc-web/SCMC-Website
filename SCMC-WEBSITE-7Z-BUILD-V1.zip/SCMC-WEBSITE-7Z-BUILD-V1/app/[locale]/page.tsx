import type { Metadata } from "next";
import Image from "next/image";
import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { ServiceStory } from "@/components/ServiceStory";
import { doctors } from "@/lib/doctors";
import { isLocale } from "@/lib/i18n";
import { localizedMetadata } from "@/lib/metadata";
import { copy, site } from "@/lib/site";

export async function generateMetadata({ params }: { params: Promise<{ locale: string }> }): Promise<Metadata> {
  const { locale: raw } = await params;
  const locale = isLocale(raw) ? raw : "en";
  return localizedMetadata(
    locale,
    locale === "ar" ? "مركز سمايل كير الطبي" : "Smile Care Medical Center",
    locale === "ar"
      ? "مركز طبي متعدد التخصصات في رأس الخيمة لخدمات الأسنان والجلدية والتجميل والليزر والمختبر."
      : "A multidisciplinary medical center in Ras Al Khaimah for dentistry, dermatology, aesthetics, laser and laboratory services."
  );
}

export default async function HomePage({ params }: { params: Promise<{ locale: string }> }) {
  const { locale: raw } = await params;
  const locale = isLocale(raw) ? raw : "en";
  const c = copy[locale];
  const whatsapp = `https://wa.me/${site.whatsapp.replace(/\D/g, "")}`;

  return (
    <>
      <section className="home-hero">
        <div className="hero-grid">
          <div className="hero-copy">
            <span className="eyebrow" data-reveal>{c.eyebrow}</span>
            <h1 className="display" data-reveal>{c.heroTitle}</h1>
            <p className="lead" data-reveal>{c.heroBody}</p>
            <div className="hero-actions" data-reveal>
              <Link href={`/${locale}/contact#appointment`} className="pill-button dark">
                <span>{c.primaryCta}</span><ArrowUpRight size={17} strokeWidth={1.5} />
              </Link>
              <a href={whatsapp} target="_blank" rel="noreferrer" className="pill-button outline">
                <span>{c.secondaryCta}</span>
              </a>
            </div>
          </div>
          <div className="hero-media" data-hero-media>
            <Image src="/media/clinic/DSC08063.webp" alt="Smile Care Medical Center interior" fill sizes="(max-width: 900px) 100vw, 48vw" priority />
            <div className="hero-orbit">
              <strong>{locale === "ar" ? "رأس الخيمة" : "Ras Al Khaimah"}</strong>
              <span>{locale === "ar" ? "رعاية متعددة التخصصات" : "Multidisciplinary care"}</span>
            </div>
          </div>
          <Image className="hero-mark" src="/brand/scmc-mark-emerald.png" width={844} height={430} alt="" aria-hidden />
          <div className="hero-facts" data-reveal>
            <div className="hero-fact"><strong>{locale === "ar" ? "منذ 2007" : "Since 2007"}</strong><span>{locale === "ar" ? "في رأس الخيمة" : "Established in Ras Al Khaimah"}</span></div>
            <div className="hero-fact"><strong>{locale === "ar" ? "مركز طبي واحد" : "One medical center"}</strong><span>{locale === "ar" ? "أسنان · جلدية · تجميل · ليزر · مختبر" : "Dental · Skin · Aesthetics · Laser · Laboratory"}</span></div>
            <div className="hero-fact"><strong>MOHAP {site.mohap}</strong><span>{locale === "ar" ? "رقم الترخيص" : "License number"}</span></div>
          </div>
        </div>
      </section>

      <section className="story-section">
        <div className="shell">
          <div className="story-head">
            <div>
              <span className="eyebrow" data-reveal>{locale === "ar" ? "القصة" : "The story"}</span>
              <h2 className="section-title" data-reveal>{c.storyTitle}</h2>
            </div>
            <div className="story-copy" data-reveal><p>{c.storyBody}</p></div>
          </div>
          <div className="story-gallery">
            <div className="story-image" data-reveal>
              <Image src="/media/clinic/DSC08068.webp" alt="Smile Care Medical Center signage" fill sizes="(max-width: 900px) 100vw, 58vw" data-parallax />
              <span className="story-stamp">{locale === "ar" ? "هوية معروفة في رأس الخيمة" : "A familiar mark in Ras Al Khaimah"}</span>
            </div>
            <div className="story-image secondary" data-reveal>
              <Image src="/media/clinic/DSC08007.webp" alt="Smile Care Medical Center lounge" fill sizes="(max-width: 900px) 100vw, 38vw" data-parallax />
              <span className="story-stamp">{locale === "ar" ? "راحة قبل العلاج" : "Comfort before treatment"}</span>
            </div>
          </div>
        </div>
      </section>

      <section className="services-chapter">
        <div className="shell">
          <div className="service-section-head">
            <div>
              <span className="eyebrow" data-reveal>{c.serviceEyebrow}</span>
              <h2 className="section-title" data-reveal>{c.serviceTitle}</h2>
            </div>
            <p className="lead" data-reveal>{locale === "ar" ? "تنقّل بين التخصصات كما لو كانت فصولاً في تجربة واحدة، بدل أن تبدو كخدمات منفصلة." : "Move through each specialty as a chapter in one patient experience, rather than a collection of disconnected departments."}</p>
          </div>
          <ServiceStory locale={locale} />
        </div>
      </section>

      <section className="team-section">
        <div className="shell team-head">
          <div>
            <span className="eyebrow" data-reveal>{c.teamEyebrow}</span>
            <h2 className="section-title" data-reveal>{c.teamTitle}</h2>
          </div>
          <p className="lead" data-reveal>{locale === "ar" ? "فريق طبي يغطي طب الأسنان والجلدية والتجميل والتخصصات السنية، ضمن مركز واحد." : "A medical team spanning general dentistry, dental specialties, dermatology and aesthetics under one roof."}</p>
        </div>
        <div className="doctor-rail">
          {doctors.map((doctor) => (
            <Link href={`/${locale}/doctors/${doctor.slug}`} className="doctor-card" key={doctor.slug}>
              <div className="doctor-photo"><Image src={doctor.image} alt={doctor.name[locale]} fill sizes="(max-width: 520px) 76vw, (max-width: 900px) 55vw, 23vw" /></div>
              <div className="doctor-info"><h3>{doctor.name[locale]}</h3><p>{doctor.specialty[locale]}</p></div>
            </Link>
          ))}
        </div>
      </section>

      <section className="environment-section">
        <div className="shell environment-grid">
          <div className="environment-copy">
            <span className="eyebrow" data-reveal>{c.environmentEyebrow}</span>
            <h2 className="section-title" data-reveal>{c.environmentTitle}</h2>
            <p className="lead" data-reveal>{c.environmentBody}</p>
            <Link className="text-link" href={`/${locale}/about`} data-reveal>
              <span>{locale === "ar" ? "اقرأ قصة سمايل كير" : "Read the Smile Care story"}</span><ArrowUpRight size={17} strokeWidth={1.5} />
            </Link>
          </div>
          <div className="environment-media">
            <div className="environment-image" data-reveal><Image src="/media/clinic/DSC08032.webp" alt="Smile Care waiting area" fill sizes="(max-width: 900px) 100vw, 38vw" /></div>
            <div className="environment-image small" data-reveal><Image src="/media/clinic/DSC08057.webp" alt="Smile Care treatment room" fill sizes="(max-width: 900px) 100vw, 28vw" /></div>
          </div>
        </div>
      </section>

      <section className="closing-section">
        <Image className="closing-mark" src="/brand/scmc-mark-gold.png" width={844} height={430} alt="" aria-hidden />
        <div className="shell closing-grid">
          <div>
            <span className="eyebrow" data-reveal>{locale === "ar" ? "الخطوة التالية" : "Next step"}</span>
            <h2 className="section-title" data-reveal>{c.closingTitle}</h2>
            <p className="lead" data-reveal>{c.closingBody}</p>
            <div className="hero-actions" data-reveal>
              <Link href={`/${locale}/contact#appointment`} className="pill-button light">{c.primaryCta}</Link>
              <a href={whatsapp} target="_blank" rel="noreferrer" className="pill-button outline">WhatsApp</a>
            </div>
          </div>
          <div className="contact-mini" data-reveal>
            <span>{site.location[locale]}</span>
            <a href={`tel:${site.phone}`}>{site.phone}</a>
            <a href={`mailto:${site.email}`}>{site.email}</a>
            <span>{site.hours[locale]}</span>
          </div>
        </div>
      </section>
    </>
  );
}
