"use client";

import { useEffect } from "react";
import gsap from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

export function MotionOrchestrator() {
  useEffect(() => {
    if (typeof window === "undefined") return;
    gsap.registerPlugin(ScrollTrigger);

    const reduce = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) return;

    const ctx = gsap.context(() => {
      gsap.utils.toArray<HTMLElement>("[data-reveal]").forEach((element) => {
        gsap.fromTo(
          element,
          { opacity: 0, y: 28 },
          {
            opacity: 1,
            y: 0,
            duration: 0.9,
            ease: "power3.out",
            scrollTrigger: { trigger: element, start: "top 88%", once: true },
          }
        );
      });

      const heroMedia = document.querySelector<HTMLElement>("[data-hero-media]");
      if (heroMedia && window.innerWidth >= 900) {
        gsap.to(heroMedia, {
          yPercent: 8,
          ease: "none",
          scrollTrigger: { trigger: heroMedia, start: "top top", end: "bottom top", scrub: 0.6 },
        });
      }

      gsap.utils.toArray<HTMLElement>("[data-parallax]").forEach((element) => {
        if (window.innerWidth < 768) return;
        gsap.fromTo(
          element,
          { yPercent: -4 },
          {
            yPercent: 4,
            ease: "none",
            scrollTrigger: { trigger: element, start: "top bottom", end: "bottom top", scrub: 0.8 },
          }
        );
      });
    });

    return () => ctx.revert();
  }, []);

  return null;
}
